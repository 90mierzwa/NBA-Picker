package nbapicker;

public class teamCases {
    
       
    public static float[] teamPick1 (int teamPick1){
        
        float[] teamA = {0.0f};
        
        switch(teamPick1){
            case 1:
              teamA = teams.atlHawks;
               break;
               
            case 2:
                teamA = teams.bosCeltics;
                break;
                
            case 3:
                teamA = teams.brklndNets;
                break;
                
            case 4:
                teamA = teams.charHornets;
                break;
                
            case 5:
                teamA = teams.chicBulls;
                break;
                
            case 6:
                teamA = teams.clvCavaliers;
                break;
                
            case 7:
                teamA = teams.dalMavericks;
                break;
                
            case 8:
                teamA = teams.denNuggets;
                break;
                
            case 9:
                teamA = teams.detPistons;
                break;
                
            case 10:
                teamA = teams.goldstWarriors;
                break;
                
            case 11:
                teamA = teams.houRockets;
                break;
                
            case 12:
                teamA = teams.indPacers;
                break;
                
            case 13:
                teamA = teams.laClippers;
                break;
                
            case 14:
                teamA = teams.laLakers;
                break;
                
            case 15:
                teamA = teams.memGrizzlies;
                break;
                
            case 16:
                teamA = teams.miaHeat;
                break;
                
            case 17:
                teamA = teams.milBucks;
                break;
                
            case 18:
                teamA = teams.minTimberwolves;
                break;
                
            case 19:
                teamA = teams.noPelicans;
                break;
                
            case 20:
                teamA = teams.nyKnicks;
                break;
                
            case 21:
                teamA = teams.okcThunder;
                break;
                
            case 22:
                teamA = teams.orlMagic;
                break;
                
            case 23:
                teamA = teams.phil76ers;
                break;
                
            case 24:
                teamA = teams.phnxSuns;
                break;
                
            case 25:
                teamA = teams.prtTrailblazers;
                break;
                
            case 26:
                teamA = teams.sacKings;
                break;
                
            case 27:
                teamA = teams.sanSpurs;
                break;
                
            case 28:
                teamA = teams.torRaptors;
                break;
                
            case 29:
                teamA = teams.utahJazz;
                break;
                
            case 30:
                teamA = teams.washWizards;
                break;
        }
        
        return teamA;
        
    }
    
    
    public static float[] teamPick2 (int teamPick2){
        
        float[] teamB= {0.0f};
        
        switch(teamPick2){
            case 1:
              teamB = teams.atlHawks;
              break;
               
            case 2:
                teamB = teams.bosCeltics;
                break;
                
            case 3:
                teamB = teams.brklndNets;
                break;
                
            case 4:
                teamB = teams.charHornets;
                break;
                
            case 5:
                teamB = teams.chicBulls;
                break;
                
            case 6:
                teamB = teams.clvCavaliers;
                break;
                
            case 7:
                teamB = teams.dalMavericks;
                break;
                
            case 8:
                teamB = teams.denNuggets;
                break;
                
            case 9:
                teamB = teams.detPistons;
                break;
                
            case 10:
                teamB = teams.goldstWarriors;
                break;
                
            case 11:
                teamB = teams.houRockets;
                break;
                
            case 12:
                teamB = teams.indPacers;
                break;
                
            case 13:
                teamB = teams.laClippers;
                break;
                
            case 14:
                teamB = teams.laLakers;
                break;
                
            case 15:
                teamB = teams.memGrizzlies;
                break;
                
            case 16:
                teamB = teams.miaHeat;
                break;
                
            case 17:
                teamB = teams.milBucks;
                break;
                
            case 18:
                teamB = teams.minTimberwolves;
                break;
                
            case 19:
                teamB = teams.noPelicans;
                break;
                
            case 20:
                teamB = teams.nyKnicks;
                break;
                
            case 21:
                teamB = teams.okcThunder;
                break;
                
            case 22:
                teamB = teams.orlMagic;
                break;
                
            case 23:
                teamB = teams.phil76ers;
                break;
                
            case 24:
                teamB = teams.phnxSuns;
                break;
                
            case 25:
                teamB = teams.prtTrailblazers;
                break;
                
            case 26:
                teamB = teams.sacKings;
                break;
                
            case 27:
                teamB = teams.sanSpurs;
                break;
                
            case 28:
                teamB = teams.torRaptors;
                break;
                
            case 29:
                teamB = teams.utahJazz;
                break;
                
            case 30:
                teamB = teams.washWizards;
                break;
        }
        
         return teamB;
         
    }    
}