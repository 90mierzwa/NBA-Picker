// Shooting %, win %, assists PG, turnovers PG, possessions PG, fouls committed PG, free throws made PG, 3 Pointers made PG
// Off Reb PG, Def Reb PG, FG attempts, offensive rating, def rating, home court, dist tavelled, eff FG %, avg scoring margin,
// http://www.sfandllaw.com/Articles/What-Wins-Basketball-Games-a-Review-of-Basketball-on-Paper-Rules-and-Tools-for-Performance-Analysis.shtml
// https://coachingtoolbox.net/blog/the-five-most-important-factors-in-winning-basketball-games

// 4/5/2018 Schedule: GSW vs IND; WAS vs. CLE; POR vs HOU; BRK vs MIL; LAC vs UTAH; MINN vs DEN
// 4/5/2018 Predictions: GSW win; CLE win; HOU wins; MIL wins; LA wins; DEN wins --> 3/6 correct = 50% success

// 4/7/2018 Schedule: DEN vs. LAC; MIL vs. NYK; NETS vs. CHI; OKC vs. HOU; NO vs. GSW; POR vs. SAN
// 4/7/2018 Predictions: DEN win; MIL wins; BKN wins; HOU wins; GSW win; SAN wins --> 4/6 correct = 67% success

// 4/11/2018 Schedule: BKN vs. BOS; NY vs. CLE; TOR vs. MIA; WAS vs. ORL; MIL vs. PHI; DET vs. CHI; DEN vs. MIN; SAN vs. NO; MEM vs. OKC; LAL vs. LAC; UTAH vs. POR; HOU vs. SAC 
// 4/11/2018 Predictons: BOS win; CLE win; 
// WHAT HAPPENS IF TIE!!!!!!!!!

package nbapicker;

import java.util.Scanner; 

public class NBApicker {
     
    static float teamACounter = 0;
    static float teamBCounter = 0;
        
    static private float shootingPercent(float[] a, float[] b){
        
        
        if(a[0] > b[0]){
            teamACounter += 52.459;     // 52.459% of games sampled were won by team with advantage in shooting percentage  
            return teamACounter;
        }
        else 
            teamBCounter += 52.459;
            return teamBCounter;       
    }
    
    static private float winPercent(float[] a, float[] b){ 
        
        if(a[1] > b[1]){
            teamACounter += 63.9344;   // 63.9344% of games sampled were won by team with advantage in win percentage 
            return teamACounter;
        }
        else 
            teamBCounter += 63.9344;
            return teamBCounter;       
    }
    
    static private float assists(float[] a, float[] b){
        
         if(a[2] > b[2]){
          teamACounter += 75.4098;   // 75.4098% of games sampled were won by team with advantage in assists PG
            return teamACounter;
        }
        else 
            teamBCounter += 75.4098;
            return teamBCounter;
        
    }
    
    static private float turnovers(float[] a, float[] b){   // more turnovers is bad
        
         if(a[3] < b[3]){
             teamACounter += 54.098;                         // 54.098% of games sampled were won by team with lower turnovers PG 
            return teamACounter;
        }
        else 
            teamBCounter += 54.098;
            return teamBCounter;
        
    }
    
    static private float possessionsPerGame(float[] a, float[] b){
        
         if(a[4] > b[4]){
             teamACounter += 50.8197;                                 // 50.8197% of games sampled were won by team with advantage in possessions PG won 
            return teamACounter;
        }
        else 
            teamBCounter += 50.8197;
            return teamBCounter;
        
    }
    
    static private float foulsComitted(float[] a, float[] b){  // more fouls committed is bad  
        
         if(a[5] < b[5]){
             teamACounter += 59.0164;                           // 59.0164% of games sampled were won by team with advtantage in fouls committed per game n           
            return teamACounter;
        }
        else 
            teamBCounter += 59.0164;
            return teamBCounter;
        
    }
    
    static private float freeThrowsPG(float[] a, float[] b){
        
         if(a[6] > b[6]){
             teamACounter += 57.377;                            // 57.377% of games sampled were won by team with advantage in FT made PG 
            return teamACounter;
        }
        else 
            teamBCounter += 57.377;
            return teamBCounter;
        
    }
    
    static private float threePointersPG(float[] a, float[] b){
        
         if(a[7] > b[7]){
             teamACounter += 68.852;                    // 68.852% of games sampled were won by team with advantage in 3s made PG  
            return teamACounter;
        }
        else 
            teamBCounter += 68.852;
            return teamBCounter;
        
    }
    
    static private float offensiveReboundsPG(float[] a, float[] b){
        
         if(a[8] > b[8]){
             teamACounter += 45.902;                            // 45.902% of games sampled were won by team with advantage in Off Reb PG 
            return teamACounter;
        }
        else 
            teamBCounter += 45.902;
            return teamBCounter;
        
    }
    
    static private float defensiveReboundsPG(float[] a, float[] b) {
        
         if(a[9] > b[9]){
             teamACounter += 55.738;                         // 55.738% of games sampled were won by team with advantage in Def Reb PG
            return teamACounter;
        }
        else 
            teamBCounter += 55.738;
            return teamBCounter;
        
    }
    
    static private float fieldGoalAttemptsPG(float[] a, float[] b) {
        
         if(a[10] > b[10]){
             teamACounter += 45.902;                //45.902% of games sampled were won by team with advantage in FG Attempts PG
            return teamACounter;
        }
        else 
            teamBCounter += 45.902;
            return teamBCounter;
        
    }
    
    static private float offensiveRating(float[] a, float[] b){
        
         if(a[11] > b[11]){
             teamACounter += 59.016;                   //59.016% of games sampled were won by team with advantage in Off Rating
            return teamACounter;
        }
        else 
            teamBCounter += 59.016;
            return teamBCounter;
        
    }
    
    static private float defensiveRating(float[] a, float[] b){     // Lower defensive rating is better 
        
         if(a[12] < b[12]){
             teamACounter += 59.016;                //59.016% of games sampled were won by team with advantage in Def Rating
            return teamACounter;
        }
        else 
            teamBCounter += 59.016;
            return teamBCounter;
        
    }
    
    static private float homeCourtAdv(float[] a, float[] b){
        
         if(a[13] > b[13]){
              teamACounter += 59.016;           // 59.016% of games sampled were won by team with home court advantage 
            return teamACounter;
        }
        else 
            teamBCounter += 59.016;
            return teamBCounter;
        
    }
    
    /*static private float distanceTraveledOneWeek(float[] a, float[] b){   // more distance travelled is bad for team 
        
         if(a[14] > b[14]){
             teamACounter -= 14.59;     
            return teamACounter;
        }
        else 
            teamBCounter -= 14.59;
            return teamBCounter;
        
    }  */
    
    static private float effectiveFieldGoalPercentage(float[] a, float[] b){
        
         if(a[15] > b[15]){
             teamACounter += 65.574;                // 65.574% of games sampled were won by team with advantage in Eff FG %
            return teamACounter;
        }
        else 
            teamBCounter += 65.574;
            return teamBCounter;
        
    }
    
    static private float averageScoringMargin(float[] a, float[] b){
        
         if(a[16] > b[16]){
             teamACounter += 62.295;                    // 62.259% of game sampled were won by team with advantage in avgerage scoring margin
            return teamACounter;
        }
        else 
            teamBCounter += 62.295;
            return teamBCounter;
        
    }
    
    
    
  
    public static void main(String[] args) {
        
     
        System.out.println("Choose the matchup");        
        for (int i = 0; i < teams.chooseTeam.length; i++){
            System.out.println(i+1 + ". " + teams.chooseTeam[i]);
            
        }
        
        Scanner keyboard = new Scanner(System.in);
        int Pick1 = keyboard.nextInt();
        int Pick2 = keyboard.nextInt();
        teamCases tc = new teamCases();
        teams t = new teams();
        
        // Calling functions to compare each statistical category
        shootingPercent(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        winPercent(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        assists(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        turnovers(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        possessionsPerGame(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        foulsComitted(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        freeThrowsPG(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        threePointersPG(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        offensiveReboundsPG(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        defensiveReboundsPG(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        fieldGoalAttemptsPG(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        offensiveRating(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        defensiveRating(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        homeCourtAdv(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        //distanceTraveledOneWeek(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        effectiveFieldGoalPercentage(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        averageScoringMargin(tc.teamPick2(Pick1), tc.teamPick1(Pick2));
        
        /*javax.swing.SwingUtilities.invokeLater(new Runnable() {            
        public void run() {
                calcGui.createGUI(); 
            }
            GUI calcGui = new GUI ();
        }); */
        
        System.out.println("Value of teamACounter = " + teamACounter);
        System.out.println("Value of teamBCounter = " + teamBCounter);
        
        if (teamACounter > teamBCounter){
            System.out.println("Team A is projected to win!");
        }
        
        else
            System.out.println("Team B is projected to win!");
        
    }      
}


    