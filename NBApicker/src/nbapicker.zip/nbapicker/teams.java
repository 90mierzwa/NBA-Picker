/*0 = Shooting %
1 = win %
2 = assists PG
3 = turnovers PG
4 = possessions PG
5 = fouls committed PG
6 = free throws made PG
7 = 3 Pointers made PG
8 = Off Reb PG
9 = Def Reb PG
10 = FG attempts 
11 = offensive rating
12 = def rating
13 = home court
14 = dist tavelled
15 = eff FG %
16 = avg scoring margin 
17 = win % last 7 games */


package nbapicker;

public class teams {
    
    public static String[] chooseTeam = {"Atlanta Hawks", "Boston Celtics", "Brooklyn Nets" , "Charlotte Hornets", "Chicago Bulls", "Cleveland Cavaliers", "Dallas Mavericks", "Denver Nuggets", 
    "Detroit Pistons", "Golden State Warriors", "Houston Rockets", "Indiana Pacers", "Los Angeles Clippers", "Los Angeles Lakers", "Memphis Grizzlies", "Miami Heat", "Milwaukee Bucks", "Minnesota Timberwolves", "New Orleans Pelicans", "New York Knicks",
    "Oklahoma City Thunder", "Orlando Magic", "Philadelphia 76ers", "Phoenix Suns", "Portland Trailblazers", "Sacramento Kings", "San Antonio Spurs", "Toronto Raptors", "Utah Jazz", "Washington Wizards"};
    static float atlHawks[];
    static float bosCeltics[] =     { .450f, .667f, 22.5f, 14.0f, 99.5f, 19.8f, 16.0f, 11.5f, 9.2f, 35.0f, 84.9f, 105.2f, 101.6f, 1.0f, 100.0f, .518f, 3.5f};
    
    static float brklndNets[] =     { .440f, .329f, 23.4f, 15.1f, 102.7f, 20.8f, 17.6f, 12.5f, 9.8f, 34.7f, 86.7f, 104.2f, 108.8f, 0.0f, 2324.4f, .512f, -4.2f};
    
    static float charHornets[];
    static float chicBulls[] =      { .436f, .342f, 23.5f, 13.9f, 101.9f, 19.3f, 14.6f, 11.1f, 9.7f, 35.1f, 88.9f, 101.6f, 108.8f, 1.0f, 1965.0f, .498f, -6.4f}; ;
    static float clvCavaliers[] =   { .476f, .615f, 23.4f, 13.7f, 100.9f, 18.7f, 17.9f, 11.9f, 8.4f, 33.7f, 84.7f, 110.4f, 109.3f, 1.0f, 1244.1f, .546f, 0.9f};
    static float dalMavericks[];
    
    static float denNuggets[] =     { .469f, .557f, 25.1f, 15.1f, 100.9f, 18.6f, 17.2f, 11.5f, 11.1f, 33.5f, 86.6f, 109.5f, 109.0f, 0.0f, 1015.9f, .536f, 1.3f};
    
    static float detPistons[];
    
    static float goldstWarriors[] = { .504f, .722f, 29.5f, 15.5f, 102.9f, 19.7f, 16.8f, 11.3f, 8.5f, 35.2f, 85.0f, 113.5f, 103.0f, 1.0f, 4708.7f, .575f, 6.6f};
    
    static float houRockets[] =     { .461f, .810f, 21.7f, 13.7f, 100.9f, 19.4f, 19.9f, 15.4f, 9.1f, 34.4f, 84.3f, 112.8f, 103.9f, 1.0f, 197.7f, .552f, 9.0f};
    
    static float indPacers[] =      { .474f, .590f, 22.1f, 13.3f, 99.1f, 18.7f, 15.1f, 9.0f, 9.5f, 32.6f, 86.0f, 107.4f, 105.6f, 1.0f, 2485.3f, .526f, 1.7f};
    static float laClippers[] =     { .471f, .532f, 22.2f, 14.7f, 102.0f, 20.1f, 19.2f, 9.7f, 10.0f, 33.7f, 85.3f, 107.9f, 107.2f, 1.0f, 1376.8f, .528f, 0.6f};
    static float laLakers[];    
    static float memGrizzlies[];
    static float miaHeat[];
    static float milBucks[] =       { .480f, .532f, 23.1f, 13.8f, 99.9f, 21.6f, 18.4f, 8.8f, 8.3f, 31.2f, 82.7f, 108.1f, 107.3f, 0.0f, 1925.9f, 53.3f, -0.1f};
    static float minTimberwolves[]= { .480f, .581f, 22.7f, 12.7f, 99.7f, 17.9f, 19.3f, 8.2f, 10.0f, 31.5f, 85.5f, 110.8f, 108.9f, 0.0f, 2026.5f, .525f, 1.9f};
    static float noPelicans[] =     { .481f, .570f, 26.5f, 15.0f, 104.9f, 19.2f, 16.2f, 10.3f, 8.7f, 35.6f, 88.2f, 107.3f, 105.7f, 0.0f, 2263.6f, .539f, 0.8f};
    
    static float nyKnicks[] =       { .463f, .354f, 23.1f, 14.8f, 100.8f, 20.5f, 15.1f, 8.1f, 10.5f, 33.7f, 87.7f, 103.9f, 108.3f, 0.0f, 0.0f, .509f, -3.5f};  
    
    static float okcThunder[] =     { .453f, .570f, 21.2f, 14.1f, 100.7f, 20.2f, 17.0f, 10.6f, 12.6f, 32.5f, 88.2f, 107.3f, 104.7f, 0.0f, 1152.8f, .513f, 3.0f};
    static float orlMagic[];
    
    static float phil76ers[];
    static float phnxSuns[];
    
    static float prtTrailblazers[]= { .453f, .608f, 19.6f, 13.5f, 100.0f, 19.4f, 16.9f, 10.4f, 10.1f, 35.3f, 86.8f, 106.4f, 104.3f, 0.0f, 2474.7f, .513f, 2.8f};
    static float sacKings[];
    static float sanSpurs[] =       { .457f, .570f, 22.9f, 13,2f, 98.1f, 17.3f, 16.1f, 8.5f, 10.4f, 34.0f, 85.3f, 105.5f, 102.2f, 1.0f, 2706.8f, .508f, 3.0f};
    static float torRaptors[];
    static float utahJazz[] =       { .461f, .577f, 22.2f, 14.7f, 98.8f, 19.5f, 16.8f, 10.8f, 8.9f, 34.1f, 82.7f, 106.0f, 102.0f, 1.0f, 1970.0f, .526f, 3.7f};
    static float washWizards[] =    { .468f, .538f, 25.2f, 14.6f, 100.5f, 21.3f, 16.9f, 9.9f, 9.9f, 33.0f, 85.4f, 107.1f, 106.3f, 0.0f, 3615.2f, .526f, 0.7f };
    
}

